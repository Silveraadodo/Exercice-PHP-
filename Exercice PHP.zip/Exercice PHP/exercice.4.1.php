<?php
/**
 * ecrire un script qui génère deux points A(xA,yA) B(xB,yB)
 * le scrpt affiche les deux points puis détermine et affiche la distance 
 * qui sépare ces deux points
 */
define("MIN",1);
define("MAX",100);
$point_xA=rand(MIN,MAX);
$point_xB=rand(MIN,MAX);
$point_yA=rand(MIN,MAX);
$point_yB=rand(MIN,MAX);
$distance=sqrt(pow(($point_xB-$point_xA),2)+pow(($point_yB-$point_yA),2));
echo("la distance entre le point A($point_xA,$point_yA) et le point B($point_xB,$point_yB) est $distance");



?>
