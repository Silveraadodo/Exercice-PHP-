<?php
/** ecrire un script qui génère 3 nombres 
 * puis les tri dans l'ordre croissant bet après dans l'ordre décroissant
 */
 
 
$nombreX=rand(1,100);
$nombreY=rand(1,100);
$nombreZ=rand(1,100);
echo("<br>");echo("<br>");
echo("affichage des nombres dans l'ordre croissant ");
if($nombreX>$nombreY And $nombreY>$nombreZ){
     echo($nombreX. ' , '.$nombreY. ' , '.$nombreZ);
 }
elseif ($nombreY>$nombreX And $nombreX>$nombreZ){
    echo($nombreY. ' , '.$nombreX. ' , '.$nombreZ);
}
elseif ($nombreZ>$nombreX And $nombreX>$nombreY){
    echo($nombreZ. ' , '.$nombreX. ' , '.$nombreY);
}
elseif ($nombreX>$nombreZ And $nombreZ>$nombreY){
    echo($nombreX. ' , '.$nombreZ. ' , '.$nombreY);
}
elseif ($nombreY>$nombreZ And $nombreZ>$nombreX){
    echo($nombreY. ' , '.$nombreZ. ' , '.$nombreX);
}
elseif ($nombreZ>$nombreY And $nombreY>$nombreX){
    echo($nombreZ. ' , '.$nombreY. ' , '.$nombreX);
}echo("<br>");echo("<br>");

echo("affichage des nombres dans l'ordre décroissant ");
if($nombreX<$nombreY And $nombreY<$nombreZ){
     echo($nombreX. ' , '.$nombreY. ' , '.$nombreZ);
 }
elseif ($nombreY<$nombreX And $nombreX<$nombreZ){
    echo($nombreY. ' , '.$nombreX. ' , '.$nombreZ);
}
elseif ($nombreZ<$nombreX And $nombreX<$nombreY){
    echo($nombreZ. ' , '.$nombreX. ' , '.$nombreY);
}
elseif ($nombreX<$nombreZ And $nombreZ<$nombreY){
    echo($nombreX. ' , '.$nombreZ. ' , '.$nombreY);
}
elseif ($nombreY<$nombreZ And $nombreZ<$nombreX){
    echo($nombreY. ' , '.$nombreZ. ' , '.$nombreX);
}
elseif ($nombreZ<$nombreY And $nombreY<$nombreX){
    echo($nombreZ. ' , '.$nombreY. ' , '.$nombreX);
}echo("<br>");echo("<br>");
?>